using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trigger : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Object has started pushing the door");
    }
    private void OnTriggerStay(Collider other)
    {
        Debug.Log("Object is touching the door");
    }
    private void OnTriggerExit(Collider other)
    {
        Debug.Log("Object has stopped pushing the door");
    }
   
}
