using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Force : MonoBehaviour
{
    public Rigidbody Rigidbody;
    public Vector3 VectorForce;

    private void Start()
    {
        Rigidbody.AddForce(VectorForce, ForceMode.Impulse);
    }
}

  
